@extends('layouts.app')
@section('title', 'User Accounts')
@section('breadcrumb', 'User Accounts')
@section('content')
    <div class="eyebrow">TEAM DIRECTORY</div><div class="heading-row"><div><h1>User Accounts<span class="accent">.</span></h1><p class="lead">See the staff members, positions and locations in the demo POS.</p></div><span class="count-chip">{{ count($users) }} users</span></div>
    <div class="table-panel"><div class="table-panel-head"><div><h2>All system users</h2><p>Staff records, assigned roles, branch and account status.</p></div><span class="static-label">STATIC DATA</span></div><div class="table-scroll"><table><thead><tr><th>User</th><th>User ID</th><th>Role</th><th>Assigned branch</th><th>Status</th></tr></thead><tbody>
    @foreach ($users as $user)
        <tr><td><div class="person"><span class="person-avatar amber">{{ strtoupper(substr($user['name'], 0, 1)) }}</span><span><strong>{{ $user['name'] }}</strong><small>{{ $user['email'] }}</small></span></div></td><td class="mono">{{ $user['id'] }}</td><td><span class="tier">{{ $user['role'] }}</span></td><td>{{ $user['branch'] }}</td><td><span class="status {{ $user['status'] === 'Active' ? 'status-active' : 'status-inactive' }}"><i></i>{{ $user['status'] }}</span></td></tr>
    @endforeach
    </tbody></table></div><div class="table-foot">Showing {{ count($users) }} of {{ count($users) }} user accounts <span>Source: UserController PHP array</span></div></div>
@endsection
