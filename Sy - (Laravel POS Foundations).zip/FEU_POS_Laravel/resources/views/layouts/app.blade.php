<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#102d29">
    <title>@yield('title', 'POS Dashboard') | Northstar POS</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar" aria-label="Sidebar">
        <a class="brand" href="{{ route('home') }}"><span class="brand-symbol">N</span><span>northstar<span class="brand-light">/pos</span><small>RETAIL OPERATIONS</small></span></a>
        <div class="side-label">WORKSPACE</div>
        <nav class="side-nav" aria-label="Main navigation">
            <a class="nav-item {{ request()->routeIs('home') ? 'active' : '' }}" href="{{ route('home') }}"><span class="nav-ico">◫</span>Overview</a>
            <a class="nav-item {{ request()->routeIs('customers.*') ? 'active' : '' }}" href="{{ route('customers.index') }}"><span class="nav-ico">♙</span>Customer Accounts</a>
            <a class="nav-item {{ request()->routeIs('users.*') ? 'active' : '' }}" href="{{ route('users.index') }}"><span class="nav-ico">♧</span>User Accounts</a>
        </nav>
        <div class="side-label">GENERAL</div>
        <nav class="side-nav"><a class="nav-item {{ request()->routeIs('about') ? 'active' : '' }}" href="{{ route('about') }}"><span class="nav-ico">ⓘ</span>About the System</a></nav>
        <div class="sidebar-foot"><span class="online-dot"></span> Demo environment <small>Static dataset · Laravel</small></div>
    </aside>
    <div class="page-area">
        <header class="topbar"><div class="topbar-left">NORTHSTAR <span>/</span> @yield('breadcrumb', 'Overview')</div><div class="topbar-right"><span class="environment">● Demo mode</span><span class="avatar">NP</span></div></header>
        <main class="main-content">@yield('content')</main>
        <footer class="footer">Northstar POS <span>Laravel Laboratory Demo · Sample data only</span></footer>
    </div>
</div>
</body>
</html>
