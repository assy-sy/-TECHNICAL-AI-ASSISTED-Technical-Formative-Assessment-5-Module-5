@extends('layouts.app')
@section('title', 'Customer Accounts')
@section('breadcrumb', 'Customer Accounts')
@section('content')
    <div class="eyebrow">ACCOUNT DIRECTORY</div><div class="heading-row"><div><h1>Customer Accounts<span class="accent">.</span></h1><p class="lead">Browse the customer profiles stored in the sample dataset.</p></div><span class="count-chip">{{ count($customers) }} customers</span></div>
    <div class="table-panel"><div class="table-panel-head"><div><h2>All customers</h2><p>Contact information, membership tiers and account status.</p></div><span class="static-label">STATIC DATA</span></div><div class="table-scroll"><table><thead><tr><th>Customer</th><th>Customer ID</th><th>Phone number</th><th>Membership</th><th>Status</th></tr></thead><tbody>
    @foreach ($customers as $customer)
        <tr><td><div class="person"><span class="person-avatar">{{ strtoupper(substr($customer['name'], 0, 1)) }}</span><span><strong>{{ $customer['name'] }}</strong><small>{{ $customer['email'] }}</small></span></div></td><td class="mono">{{ $customer['id'] }}</td><td>{{ $customer['phone'] }}</td><td><span class="tier">{{ $customer['tier'] }}</span></td><td><span class="status {{ $customer['status'] === 'Active' ? 'status-active' : 'status-inactive' }}"><i></i>{{ $customer['status'] }}</span></td></tr>
    @endforeach
    </tbody></table></div><div class="table-foot">Showing {{ count($customers) }} of {{ count($customers) }} customer accounts <span>Source: CustomerController PHP array</span></div></div>
@endsection
