@extends('layouts.app')
@section('title', 'Overview')
@section('breadcrumb', 'Overview')
@section('content')
    <div class="eyebrow">OPERATIONS DASHBOARD</div>
    <div class="heading-row"><div><h1>Welcome to Northstar POS<span class="accent">.</span></h1><p class="lead">A clean, simple workspace for managing retail account records.</p></div><span class="date-chip">LABORATORY DEMO</span></div>
    <div class="hero"><div class="hero-copy"><span class="hero-tag">✦ WORKSPACE READY</span><h2>Everything in one<br>organized place.</h2><p>Browse customer information and manage an overview of your POS team in a consistent workspace.</p><a class="button button-light" href="{{ route('customers.index') }}">Explore customers <span>↗</span></a></div><div class="hero-art" aria-hidden="true"><div class="art-ring ring-one"></div><div class="art-ring ring-two"></div><div class="art-disc">N<span>+</span></div></div></div>
    <div class="section-heading"><div><h2>Quick access</h2><p>Open any workspace page with one click.</p></div></div>
    <div class="feature-grid"><a class="feature-card" href="{{ route('customers.index') }}"><span class="feature-icon green">♙</span><span class="feature-info"><strong>Customer Accounts</strong><small>View profiles, contact details and tiers</small></span><span class="feature-arrow">↗</span></a><a class="feature-card" href="{{ route('users.index') }}"><span class="feature-icon yellow">♧</span><span class="feature-info"><strong>User Accounts</strong><small>Explore team roles, branches and statuses</small></span><span class="feature-arrow">↗</span></a><a class="feature-card" href="{{ route('about') }}"><span class="feature-icon blue">ⓘ</span><span class="feature-info"><strong>About the System</strong><small>Learn how this Laravel demo is organized</small></span><span class="feature-arrow">↗</span></a></div>
    <div class="info-banner"><span>ⓘ</span><p><strong>Academic demonstration:</strong> The records shown are fictional sample entries supplied by PHP arrays. This project does not process payments or save edits to a database.</p></div>
@endsection
