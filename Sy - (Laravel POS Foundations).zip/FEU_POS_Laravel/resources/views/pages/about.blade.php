@extends('layouts.app')
@section('title', 'About')
@section('breadcrumb', 'About the System')
@section('content')
    <div class="eyebrow">GET TO KNOW THE SYSTEM</div><h1>About Northstar POS<span class="accent">.</span></h1><p class="lead">A Laravel-based reconstruction of a point-of-sale account interface for a web systems laboratory.</p>
    <div class="about-panel"><span class="hero-tag dark">SYSTEM OVERVIEW</span><h2>Built around clarity and structure.</h2><p>This demonstration features four connected pages: a landing page, an about page, a customer accounts listing, and a user accounts listing. Routes are registered in <code>routes/web.php</code> and handled by dedicated Laravel controllers. Blade templates render the interface.</p><p>Customer and user information comes from two static PHP arrays within the respective controllers. Each listing is rendered using Blade's <code>@@foreach</code> directive, without requiring database setup.</p></div>
    <div class="section-heading"><div><h2>What’s included</h2><p>Core requirements covered by this version.</p></div></div>
    <div class="about-grid"><div class="mini-card"><span>01</span><h3>4 working routes</h3><p><code>/</code>, <code>/about</code>, <code>/customers</code>, and <code>/users</code>.</p></div><div class="mini-card"><span>02</span><h3>3 controllers</h3><p>PageController, CustomerController, and UserController.</p></div><div class="mini-card"><span>03</span><h3>12 sample records</h3><p>Six fictional customers and six fictional user accounts.</p></div><div class="mini-card"><span>04</span><h3>Blade templates</h3><p>Shared page layout, navigation, and dynamic table rows.</p></div></div>
    <div class="action-row"><a class="button button-dark" href="{{ route('customers.index') }}">Customer accounts ↗</a><a class="button button-outline" href="{{ route('users.index') }}">User accounts ↗</a></div>
@endsection
