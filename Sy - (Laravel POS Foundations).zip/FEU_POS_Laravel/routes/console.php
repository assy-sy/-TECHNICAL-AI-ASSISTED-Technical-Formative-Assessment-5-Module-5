<?php
use Illuminate\Support\Facades\Artisan;
Artisan::command('inspire', function () { $this->comment('Build with Laravel.'); })->purpose('Display an inspirational message');
