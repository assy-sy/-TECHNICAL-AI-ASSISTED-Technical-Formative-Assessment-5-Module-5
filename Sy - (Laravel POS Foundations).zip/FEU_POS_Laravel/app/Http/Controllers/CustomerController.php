<?php
namespace App\Http\Controllers;

use Illuminate\View\View;

class CustomerController extends Controller
{
    public function index(): View
    {
        // Required temporary static PHP array; no database is queried.
        $customers = [
            ['id' => 'CUST-001', 'name' => 'Maria Santos', 'email' => 'maria.santos@example.com', 'phone' => '0917-000-1001', 'tier' => 'Gold', 'status' => 'Active'],
            ['id' => 'CUST-002', 'name' => 'Jose Reyes', 'email' => 'jose.reyes@example.com', 'phone' => '0917-000-1002', 'tier' => 'Silver', 'status' => 'Active'],
            ['id' => 'CUST-003', 'name' => 'Ana Cruz', 'email' => 'ana.cruz@example.com', 'phone' => '0917-000-1003', 'tier' => 'Bronze', 'status' => 'Inactive'],
            ['id' => 'CUST-004', 'name' => 'Paolo Garcia', 'email' => 'paolo.garcia@example.com', 'phone' => '0917-000-1004', 'tier' => 'Gold', 'status' => 'Active'],
            ['id' => 'CUST-005', 'name' => 'Lea Mendoza', 'email' => 'lea.mendoza@example.com', 'phone' => '0917-000-1005', 'tier' => 'Silver', 'status' => 'Active'],
            ['id' => 'CUST-006', 'name' => 'Carlo Dela Rosa', 'email' => 'carlo.delarosa@example.com', 'phone' => '0917-000-1006', 'tier' => 'Bronze', 'status' => 'Inactive'],
        ];

        return view('customers.index', compact('customers'));
    }
}
