<?php
namespace App\Http\Controllers;

use Illuminate\View\View;

class UserController extends Controller
{
    public function index(): View
    {
        // Required temporary static PHP array; no database is queried.
        $users = [
            ['id' => 'USR-001', 'name' => 'Alex Rivera', 'email' => 'alex.rivera@example.com', 'role' => 'Administrator', 'branch' => 'Main Branch', 'status' => 'Active'],
            ['id' => 'USR-002', 'name' => 'Sam Torres', 'email' => 'sam.torres@example.com', 'role' => 'Cashier', 'branch' => 'Main Branch', 'status' => 'Active'],
            ['id' => 'USR-003', 'name' => 'Kim Navarro', 'email' => 'kim.navarro@example.com', 'role' => 'Cashier', 'branch' => 'North Branch', 'status' => 'Active'],
            ['id' => 'USR-004', 'name' => 'Jamie Flores', 'email' => 'jamie.flores@example.com', 'role' => 'Manager', 'branch' => 'North Branch', 'status' => 'Active'],
            ['id' => 'USR-005', 'name' => 'Pat Aquino', 'email' => 'pat.aquino@example.com', 'role' => 'Inventory Clerk', 'branch' => 'Main Branch', 'status' => 'Inactive'],
            ['id' => 'USR-006', 'name' => 'Robin Lim', 'email' => 'robin.lim@example.com', 'role' => 'Cashier', 'branch' => 'South Branch', 'status' => 'Active'],
        ];

        return view('users.index', compact('users'));
    }
}
