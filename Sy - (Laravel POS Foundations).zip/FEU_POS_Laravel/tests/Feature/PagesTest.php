<?php
namespace Tests\Feature;
use Tests\TestCase;
class PagesTest extends TestCase
{
    public function test_all_four_pages_load(): void
    {
        foreach (['/', '/about', '/customers', '/users'] as $url) {
            $this->get($url)->assertOk();
        }
    }

    public function test_customer_and_user_tables_show_sample_data(): void
    {
        $this->get('/customers')->assertSee('Maria Santos')->assertSee('CUST-006');
        $this->get('/users')->assertSee('Alex Rivera')->assertSee('USR-006');
    }
}
